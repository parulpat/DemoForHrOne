import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookComponent } from './book/book.component';
import {ToastModule} from 'primeng/toast';
import { ButtonModule } from 'primeng/button';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import {ConfirmPopupModule} from 'primeng/confirmpopup';
import { TableModule } from 'primeng/table';
import {InputNumberModule} from 'primeng/inputnumber';
import { AuthService } from '../../services/authentication.service';

@NgModule({
  declarations: [
          BookComponent,

  ],
  imports: [
    CommonModule,
    ToastModule,
    ButtonModule,
    ConfirmDialogModule,
    ConfirmPopupModule,
    TableModule,
    InputNumberModule,
  ],
  providers: [ConfirmationService],
  exports:[
   
  ]
})
export class BookModule {
  constructor(
    private authenticationService:AuthService,
   
  ){
    this.authenticationService.currentUser.subscribe(
      x => {
        if(x && x.accessToken){
        console.log('Master Module!');
       
        }
      });
  }

}