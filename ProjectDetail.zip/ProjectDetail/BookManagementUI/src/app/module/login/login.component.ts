import { Component, OnInit } from '@angular/core';
import { LoginModel } from '../../store/model/login.model';
import { AuthService } from '../../services/authentication.service';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { AppConfigService } from 'src/app/services/app-config.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  public loginDetails: LoginModel = new LoginModel();
  submitted = false;
  returnUrl !: string;
  display = false;
  loginOff = false;
  configData: any;

  constructor(
    private authenticationService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private appConfigService: AppConfigService,
  ) {
  }

  ngOnInit(): void {
    
    this.configData = this.appConfigService.getConfig();
    //this.authenticationService.logout();
    this.returnUrl = this.route.snapshot.queryParams['returnurl'] || '/';
    
  }
  openForm() {
    this.display = true;
  }
  onSubmit(guest: boolean = false) {
    //console.log('login data:->', this.loginDetails);
    this.loginDetails.clientCode = this.getDomain(this.configData);
    this.submitted = true;
    this.authenticationService
      .login(this.loginDetails)
      .pipe(first())
      .subscribe(
        (data) => {
          
        },
        (error) => {
          
        }
      );
  }

  getDomain(data: any) {
    if (data.domainInfo && data.domainInfo.domainType === 1) {
      const url = window.location.hostname;
      console.log('url', url);
      const hostname = url.split('.')[0];
      return hostname.toUpperCase();
    } else if (data.domainInfo && data.domainInfo.domainType === 2) {
      const url = window.location.pathname;
      const hostname = url.split('/')[0];
      return hostname.toUpperCase();
    } else {
      return data.domainInfo.clientCode
        ? data.domainInfo.clientCode.toUpperCase()
        : 'STARLINK';
    }
  }
  
}
