export interface response {
    message: String;
    loginToken: String;
  }