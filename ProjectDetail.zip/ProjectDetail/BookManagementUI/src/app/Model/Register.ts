export interface Register{
    userId: 0,
    userName: string,
    password: string,
    isDeleted: true,
    role: string,
    createdBy: 0,
    createdDate: string
  }