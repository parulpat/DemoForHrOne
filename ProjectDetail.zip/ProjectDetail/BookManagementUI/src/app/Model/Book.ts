export interface Book{
    bookID: 0,
    bookName: string,
    bookAuthor: string,
    bookPublicationYear: string,
    createdBy: 0,
    createdDate: string
    updatedDate: string,
    updatedBy: 0,
    isActive: true
  }