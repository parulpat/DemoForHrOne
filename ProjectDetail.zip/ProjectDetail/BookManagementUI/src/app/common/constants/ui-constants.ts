export class UI_CONSTANT {
  
  static EMPTY_STRING = '';

  static ACTIONS = {
    ACTION: "action",
    EDIT: "edit",
    ADD:"add",
    UPDATE: "update",
    DELETE: "delete",
    
  };


  static MESSAGE_TEXT = {
    UPDATED_MESSAGE: "Changes saved successfully.",
    SAVE_BUSINESS_TYPE_MESSAGE: "Business Type saved successfully.",
    DELETED_MESSAGE: " Record deleted successfully.",
    DELECT_CONFIRM_TEXT: "Do you want to delete this record?",
    UNPROCESS_SALARY_CONFIRM_TEXT: "Do you want to delete this record?",
    PROCESS_SALARY_CONFIRM_TEXT: "Are you sure to Process this salary ?",
    PASSWORD_CHANGED_SUCCESSFULLY:"Your password has been changed successfully!",
    OTP_SENT_SUCCESSFULLY:"Please enter the one time password sent to your registered mobile/email address.",
    PUNCH_DELETE_WITH_MACHINE:"If you delete this punch, punch does not recoverd.",
    PUNCH_DELETE_WITH_MANUAL:"Are you sure delete this punch."
  };
  static SEVERITY = {
    SUCCESS: "success",
    WARNING: "warning",
    ERROR: "error",
    INFO: "info"
  };
  static CONFIRM_EVENT_TYPE = {
    REJECT: "reject",
    ACCEPT: "accept",
    CANCEL: "cancel"
  };
  static VALIDATION_TEXT = {
    REQUIRED: "is required.",
    LENGTHREQUIRED: "must be at least 5 characters long."
  };
  static ConstValue = {
    ReturnUrl: "returnUrl",
    CurrentUser: "currentUser",
  };
  static APP_TREE_ICON = {
    FOLDER_OPEN: "pi pi-folder-open",
    FOLDER_CLOSE: "pi pi-folder",
    ADD: "pi pi-plus-circle",
    UPDATE: "pi pi-pencil",
    DELETE: "pi pi-trash"
  }

}
