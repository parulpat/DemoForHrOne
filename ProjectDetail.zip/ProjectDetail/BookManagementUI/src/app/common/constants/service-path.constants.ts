export const PATH = {
    AUTH_TOKEN_API:'/Login',
    REFRESH_AUTH_TOKEN_API:'/Login/RefreshAccessToken',
    AUTHENTICATION_API: '/api/authorization/login',
    
    FETCH_BOOK: '/Book',
    
  }
