import { Component, OnInit } from '@angular/core';
import { login } from '../Model/Login';
import { LoginService } from '../Services/login.service';
import { Register } from '../Model/Register';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
public invalidLogin!:boolean;
public loginInfo: login = {} as login;
public regInfo: Register = {} as Register;
public divloginform!:boolean;
public divregisterform!:boolean;
  constructor(private loginservice:LoginService) { }

  ngOnInit(): void {
    this.divloginform=true;
    this.divregisterform=false;
  }
  login(data:login)
{

if(this.loginInfo.password=="" || this.loginInfo.userName==""){
alert("UserName and password is required")
}
else{
  this.loginservice.loginUser(data);
}

}
showRegister(){
this.divloginform=false;
this.divregisterform=true;
}
showLogin(){
  this.divloginform=true;
  this.divregisterform=false;
}
register(data:Register){
  if(this.regInfo.password=="" || this.regInfo.userName==""){
    alert("UserName and password is required")
    }
    else{
      this.loginservice.ResgiterUser(data);
      this.divloginform=true;
  this.divregisterform=false;
    }
}
}
