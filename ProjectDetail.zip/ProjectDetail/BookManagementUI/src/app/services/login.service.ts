import { Injectable } from '@angular/core';
import { login } from '../Model/Login';
import { Router } from '@angular/router';
import configurl from '../../assets/config/config.json';
import { HttpClient } from '@angular/common/http';
import { ServiceConfig } from './serviceConfig.model';
import { HttpMethod } from '../Model/http-method.constants';
import { Register } from '../Model/Register';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  public apiurl :string = configurl.apiServer.url ;
  public loginInfo: login = {} as login;
  public expirestime !:any;
  public isLoggedIn! : boolean
  constructor(private http:HttpClient, private router:Router) { }

  loginUser(data:login){
    //console.log(data);
    this.http.post(this.apiurl+ 'Login',
    data).subscribe((result:any)=>{
      if(result){
        console.log(result);
        this.expirestime = result.loginExpiretime;
        localStorage.setItem('usertoken',result.loginToken)
        this.router.navigate(['book'])
        if(localStorage.getItem('usertoken')!=""){
          this.isLoggedIn=true;
        }
        else{
          this.isLoggedIn=false;
          this.router.navigate(['login'])
        }
      }
      setTimeout(()=>{
        this.logout();
      },this.expirestime);
    })
  }
  ResgiterUser(data:Register){
    //console.log(data);
    this.http.post(this.apiurl+'RegisterUser',
    data).subscribe((result:any)=>{
      if(result){
        //console.log(result);
        alert(result.message);
        
      }
    })
  }
  logout(){
    localStorage.setItem('usertoken',"")
    this.isLoggedIn=false;
    this.router.navigate(['login'])
  }
}
