import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { login } from '../Model/Login';
import configurl from '../../assets/config/config.json';
import { Book } from '../Model/Book';
import { Observable, Observer } from 'rxjs';
import { LoginService } from './login.service';
import { Body } from '@angular/http/src/body';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  url = configurl.apiServer.url;
  bookInfo: Book[] = [];
  public responseInfo :Response = {} as Response;
  constructor(private http:HttpClient, private router:Router,private login:LoginService ) { }

  getBook():Observable<Book[]>{
    const token = localStorage.getItem("usertoken");
    const httpOptions : Object = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      }),
    };
    
   return this.http.get<Book[]>(this.url+'GetAllBook',httpOptions);
  }
  savebook(book:Book){
    const token = localStorage.getItem("usertoken");
    const httpOptions : Object = {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`,
      }),
    };
    this.http.post(this.url+'AddBook',
      book,httpOptions).subscribe((result:any)=>{
        if(result){
          //this.responseInfo = result;
          alert(result.message)
         // console.log(this.responseInfo);
          
        }
      })
  }
  updatebook(book:Book){
    const token = localStorage.getItem("usertoken");
    const httpOptions : Object = {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`,
      }),
    };
    this.http.put(this.url+'UpdateBook',
      book,httpOptions).subscribe((result:any)=>{
        if(result){
          //console.log(result.loginToken);
          alert(result.message)
      
        }
      })
  }
  getBookById(id:any):Observable<Book>{
    const token = localStorage.getItem("usertoken");
    const httpOptions : Object = {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`,
      }),
    };
    
   return this.http.get<Book>(this.url+'GetBookById/'+id,httpOptions);
  }
  deleteBookById(id:any){
    const token = localStorage.getItem("usertoken");
    const httpOptions : Object = {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`,
      }),
    };
    this.http.delete(this.url+'DeleteBook/'+id
      ,httpOptions).subscribe((result:any)=>{
        if(result){
          alert(result.message)
        }
      })
  }
}
