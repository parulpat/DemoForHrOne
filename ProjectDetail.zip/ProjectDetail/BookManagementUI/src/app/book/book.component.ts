import { Component, OnInit } from '@angular/core';
import { BookService } from '../Services/book.service';
import { Book } from '../Model/Book';
import { resolveForwardRef } from '@angular/compiler/src/util';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.scss']
})
export class BookComponent implements OnInit {
 public bookInfo: Book = {} as Book;
 public rowData:Book[]=[];
  constructor(private bookservices:BookService) { 
  }

  ngOnInit(): void {
    this.getAllBook();
  }
getAllBook(){
  this.bookservices.getBook().subscribe(res=>{
    this.rowData=res
  })
}
savebook(data:Book){
  if(data.bookName!=undefined){
    if( data.bookID != undefined){
      this.bookservices.updatebook(data);
    }else{
      this.bookservices.savebook(data);
    }
    this.bookInfo = {} as Book;
  
    setTimeout(()=>{
      this.getAllBook();
        },2000);
  }
  else{
    alert("Please fill all the detail");
  }
}

deletebook(id:any){
  this.bookservices.deleteBookById(id);
  setTimeout(()=>{
    this.getAllBook();
      },2000);

}
getbookByid(id:any){
  this.bookservices.getBookById(id).subscribe(res=>{
    this.bookInfo = res;
  });
}

}
