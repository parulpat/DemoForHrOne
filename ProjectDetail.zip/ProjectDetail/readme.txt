

Instruction -

Node version -14.0.0
Angular cli version - 12.2.7


2. Install booststarop using following commond 
npm install bootstrap

3. Is Use fa fa Icon so for that you can run the following commond
npm install @fortawesome/fontawesome-free
npm install @fortawesome/angular-fontawesome