﻿using System;
using System.ComponentModel.DataAnnotations;


namespace Database_Layer.DataModel
{
    public class BookDataModel
    {
        [Key]
        public int BookID { get; set; }
        public string BookName { get; set; }
        public string BookAuthor { get; set; }
        public string BookPublicationYear { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
