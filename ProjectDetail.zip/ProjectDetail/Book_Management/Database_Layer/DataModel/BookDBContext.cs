﻿using Database_Layer.DataModel;
using Microsoft.EntityFrameworkCore;

namespace Database_Layer
{
    public class BookDBContext : DbContext
    {
        public BookDBContext(DbContextOptions<BookDBContext> options)
            : base(options)
        {
        }
        public DbSet<BookDataModel> Books { get; set; }
        public DbSet<RegisterationDataModel>  Registerations { get; set; }
    }
}
