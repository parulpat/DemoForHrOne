﻿using System;
using System.ComponentModel.DataAnnotations;


namespace Database_Layer.DataModel
{
    public class RegisterationDataModel
    {
        [Key]
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool IsDeleted { get; set; } = false;
        public string Role { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
