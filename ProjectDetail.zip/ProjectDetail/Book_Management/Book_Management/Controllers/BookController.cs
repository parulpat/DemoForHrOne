﻿using Business_Layer.Interfaces;
using CommonLayer;
using Database_Layer.DataModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BookController : ControllerBase
    {
        private readonly IBook book;
        public BookController(IBook _book)
        {
            book = _book;
        }

        // GET: api/<BookController>
        [Route("/GetAllBook")]
        [HttpGet]
        public async Task<IEnumerable<BookDataModel>>  GetAllBook()
        {
            List<BookDataModel> bookModels = new List<BookDataModel>();
            bookModels = await book.GetAllBook();
           return bookModels;
        }

        // GET api/<BookController>/5
        [Route("/GetBookById/{id}")]
        [HttpGet]
        public async Task<BookDataModel> GetBookById(int id)
        {
            BookDataModel bookModels = new BookDataModel();
            bookModels = await book.GetBookId(id);
            return bookModels;
        }

        // POST api/<BookController>
        [Route("/AddBook")]
        [HttpPost]
        
        public async Task<ResponseModel> AddBook(BookDataModel bookmodel)
        {
            ResponseModel model = new ResponseModel();
            model = await book.AddBook(bookmodel);
            return model;
        }

        // PUT api/<BookController>/5
        [Route("/UpdateBook")]
        [HttpPut]
        public async Task<ResponseModel> UpdateBook(BookDataModel bookmodel)
        {
            ResponseModel model = new ResponseModel();
            model = await book.UpdateBook(bookmodel);
            return model;
        }

        // DELETE api/<BookController>/5
        [Route("/DeleteBook/{id}")]
        [HttpDelete]
        public async Task<ResponseModel> DeleteModel(int id)
        {
            ResponseModel model = new ResponseModel();
            model = await book.DeleteBook(id);
            return model;
        }
    }
}
