﻿using Business_Layer.Interfaces;
using CommonLayer;
using Database_Layer.DataModel;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]


    public class AuthController : ControllerBase
    {
        private readonly IAuth auth;
        public AuthController(IAuth _auth) { 
            auth = _auth;
        }

        [Route("/RegisterUser")]
        [HttpPost]
        public async Task<ResponseModel> RegisterUser([FromBody] RegisterationDataModel registrationModel)
        {
            ResponseModel responseModel = new ResponseModel();
            if (registrationModel != null)
            {
                responseModel = await auth.Registeruser(registrationModel);
            }
            else
            {
                responseModel.Message = CustomResponse.Regfailed;
            }
            return responseModel;
        }

        [Route("/Login")]
        [HttpPost]
        public async Task<ResponseModel> Login([FromBody] LoginModel loginModel)
        {
            ResponseModel responseModel = new ResponseModel();
            if (loginModel != null)
            {
                responseModel = await auth.Login(loginModel);
            }
            else
            {
                responseModel.Message = CustomResponse.Loginfaild;
            }
            return responseModel;
        }

    }
}
