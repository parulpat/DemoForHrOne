﻿using CommonLayer;
using Database_Layer.DataModel;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business_Layer.Interfaces
{
    public interface IBook
    {
        Task<List<BookDataModel>> GetAllBook(); 
        Task<BookDataModel> GetBookId(int bookId); 
        Task<ResponseModel> AddBook(BookDataModel bookModel); 
        Task<ResponseModel> UpdateBook(BookDataModel bookModel); 
        Task<ResponseModel> DeleteBook(int bookId); 
    }

   
}
