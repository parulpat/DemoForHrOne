﻿
using CommonLayer;
using Database_Layer.DataModel;
using System.Threading.Tasks;

namespace Business_Layer.Interfaces
{
    public interface IAuth
    {
        Task<ResponseModel> Registeruser(RegisterationDataModel registrationModel);
        Task<ResponseModel> Login(LoginModel  loginModel);
    }
}
