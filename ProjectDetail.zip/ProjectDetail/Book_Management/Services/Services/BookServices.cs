﻿using Business_Layer.Interfaces;
using CommonLayer;
using Database_Layer;
using Database_Layer.DataModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Services
{
    
    public class BookServices : IBook
    {
        private readonly BookDBContext _dbContext;

        public BookServices(BookDBContext context)
        {
            _dbContext = context;
        }
        public async Task<ResponseModel> AddBook(BookDataModel bookModel)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (bookModel != null)
                {
                    var isBookEixts = await _dbContext.Books.Where(x => x.BookName == bookModel.BookName).FirstOrDefaultAsync();
                    if (isBookEixts == null)
                    {
                        var roweffected = 0;
                        await _dbContext.Books.AddAsync(bookModel);
                        roweffected = await _dbContext.SaveChangesAsync();
                        if (roweffected <= 1)
                        {
                            responseModel.Message = CustomResponse.BookAdded;
                        }
                        else
                        {
                            responseModel.Message = CustomResponse.CommonMessage;
                        }
                    }
                    else
                    {
                        responseModel.Message = CustomResponse.BookExists;
                    }
                }
                else
                {
                    responseModel.Message = CustomResponse.CommonMessage;
                }
            }
            catch (Exception ex)
            {

                responseModel.Message = ex.Message;
            }
            return responseModel;
        }

        public async Task<ResponseModel> DeleteBook(int bookId)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (bookId != null)
                {
                    var book = await _dbContext.Books.Where(x => x.BookID == bookId).FirstOrDefaultAsync();
                    if (book != null)
                    {
                        var roweffected = 0;
                        book.IsActive = false;
                        _dbContext.Books.Update(book);
                        roweffected = await _dbContext.SaveChangesAsync();
                        if (roweffected <= 1)
                        {
                            responseModel.Message = CustomResponse.BookDeleted;
                        }
                        else
                        {
                            responseModel.Message = CustomResponse.CommonMessage;
                        }
                    }
                    else
                    {
                        responseModel.Message = CustomResponse.BookNotxists;
                    }
                }
                else
                {
                    responseModel.Message = CustomResponse.CommonMessage;
                }
            }
            catch (Exception ex)
            {

                responseModel.Message = ex.Message;
            }
            return responseModel;
        }

        public async Task<List<BookDataModel>> GetAllBook()
        {
            List<BookDataModel> bookModels = new List<BookDataModel>();
            bookModels = await _dbContext.Books.Where(x=>x.IsActive == true).ToListAsync();
            return bookModels;
        }

        public async Task<BookDataModel> GetBookId(int bookId)
        {
            BookDataModel bookModels = new BookDataModel();
            bookModels = await _dbContext.Books.Where(x => x.IsActive == true && x.BookID==bookId).FirstOrDefaultAsync();
            return bookModels;
        }

        public async Task<ResponseModel> UpdateBook(BookDataModel bookModel)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (bookModel != null)
                {
                    var isBookEixts = await _dbContext.Books.FindAsync(bookModel.BookID);
                    if (isBookEixts != null)
                    {
                        var roweffected = 0;
                         _dbContext.Books.Update(bookModel);
                        roweffected = await _dbContext.SaveChangesAsync();
                        if (roweffected <= 1)
                        {
                            responseModel.Message = CustomResponse.BookUpdated;
                        }
                        else
                        {
                            responseModel.Message = CustomResponse.CommonMessage;
                        }
                    }
                    else
                    {
                        responseModel.Message = CustomResponse.BookNotxists;
                    }
                }
                else
                {
                    responseModel.Message = CustomResponse.CommonMessage;
                }
            }
            catch (Exception ex)
            {

                responseModel.Message = ex.Message;
            }
            return responseModel;
        }
    }
}
