﻿using Business_Layer.Interfaces;
using CommonLayer;
using Database_Layer;
using Database_Layer.DataModel;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Services
{
    public class AuthServices : IAuth
    {
        private readonly BookDBContext _dbContext;
        private readonly IConfiguration _config;

        public AuthServices(BookDBContext context, IConfiguration config)
        {
            _dbContext = context;
            _config = config;
        }
        

        public async Task<ResponseModel> Registeruser(RegisterationDataModel registrationModel)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (registrationModel != null)
                {
                    var isUserExists =  await _dbContext.Registerations.Where(x=>x.UserName == registrationModel.UserName).FirstOrDefaultAsync();
                    if (isUserExists == null)
                    {
                        var roweffected = 0;
                        registrationModel.Role = "User";
                        await _dbContext.Registerations.AddAsync(registrationModel);
                        roweffected = await _dbContext.SaveChangesAsync();
                        if (roweffected <= 1)
                        {
                            responseModel.Message = CustomResponse.RegSuccesfull;
                        }
                        else
                        {
                            responseModel.Message = CustomResponse.CommonMessage;
                        }
                    }
                    else
                    {
                        responseModel.Message = CustomResponse.UserExists;
                    }
                }
                else
                {

                    responseModel.Message = CustomResponse.Regfailed;
                }
            }
            catch (Exception ex)
            {

                responseModel.Message = ex.Message;
            }
            return responseModel;
        } 
        public async Task<ResponseModel> Login(LoginModel loginModel)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (!String.IsNullOrEmpty(loginModel.UserName) && !String.IsNullOrEmpty(loginModel.PassWord))
                {
                   var isUserEixts = await _dbContext.Registerations.Where(x=>x.UserName == loginModel.UserName && x.Password == loginModel.PassWord).FirstOrDefaultAsync();
                    if(isUserEixts != null)
                    {
                        responseModel.LoginToken = GenerateJSONWebToken(loginModel);
                        responseModel.Message = CustomResponse.LoginSuccesfull;
                        responseModel.loginExpiretime = "7200000";
                    }
                    else
                    {
                        responseModel.Message = CustomResponse.UserNotExists;
                    }
                }
                else
                {

                    responseModel.Message = CustomResponse.Loginfaild;
                }
            }
            catch (Exception ex)
            {

                responseModel.Message = ex.Message;
            }
            return responseModel;
        }
        private string GenerateJSONWebToken(LoginModel userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["JwtConfig:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_config["JwtConfig:Issuer"],
              _config["JwtConfig:Audience"],
              null,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
