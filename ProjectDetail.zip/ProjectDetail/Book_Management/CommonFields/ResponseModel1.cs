﻿namespace CommonFields
{
    public class ResponseModel
    {
        
        public string Message { get; set; }
        public string LoginToken { get; set; }
    }
}
