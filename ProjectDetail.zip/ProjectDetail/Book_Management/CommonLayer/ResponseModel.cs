﻿using System;

namespace CommonLayer
{
    public class ResponseModel
    {
        
        public string Message { get; set; }
        public string LoginToken { get; set; }
        public string loginExpiretime { get; set; }
    }
}
