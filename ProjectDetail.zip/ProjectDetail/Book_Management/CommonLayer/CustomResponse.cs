﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer
{
    public class CustomResponse
    {
        public const string BookAdded = "Book Added Successfully";
        public const string BookUpdated = "Book Updated Successfully";
        public const string BookDeleted = "Book Deleted Successfully";
        public const string BookExists = "Book already Exists";
        public const string BookNotxists = "Book Not Exists";
        public const string Loginfaild = "Login Failed";
        public const string LoginSuccesfull = "You loggedin successfully";
        public const string RegSuccesfull = "User Registede successfully";
        public const string Regfailed = "Restration filed cannot be null";
        public const string CommonMessage = "Something Went wrong";
        public const string UserExists = "UserName already exist";
        public const string UserNotExists  = "Username or Password is wrong";
    }
}
