﻿using System;

namespace CommonLayer
{
    public class Class1
    {
    }
}
